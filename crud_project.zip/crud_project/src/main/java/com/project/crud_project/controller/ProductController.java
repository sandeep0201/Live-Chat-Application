package com.project.crud_project.controller;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.crud_project.exceptions.ProductNotFoundException;
import com.project.crud_project.model.Product;
import com.project.crud_project.repository.ProductRepository;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/restful/")
public class ProductController {

	@Autowired
	private ProductRepository productRepo;

	// GET ALL PRODUCTS
	@GetMapping("/products")
	public List<Product> getAllProducts() {
		return productRepo.findAll();
	}

	// ADD/CREATE PRODUCTS
	@PostMapping("/products")
	public Product createProduct(@RequestBody Product p) {
		return productRepo.save(p);
	}

	// GET PRODUCT BY USING ID
	@GetMapping("/products/{Id}")
	public ResponseEntity<Product> getProductById(@PathVariable Long Id) {

		Product pr = productRepo.findById(Id)
				.orElseThrow(() -> new ProductNotFoundException("Product isn't available or not exist with id: " + Id));
		return ResponseEntity.ok(pr);
	}

	// UPDATE PRODUCT
	@PutMapping("/products/{Id}")
	public ResponseEntity<Product> updateProduct(@PathVariable Long Id, @RequestBody Product prdetails) {

		Product pr = productRepo.findById(Id)
				.orElseThrow(() -> new ProductNotFoundException("Product isn't available or not exist with id: " + Id));

		pr.setProductName(prdetails.getProductName());
		pr.setProductPrice(prdetails.getProductPrice());
		pr.setProductDesc(prdetails.getProductDesc());

		Product updatedProduct = productRepo.save(pr);

		return ResponseEntity.ok(updatedProduct);
	}

	// DELETE PRODUCT
	@DeleteMapping("/products/{Id}")
	public ResponseEntity<Map<String, Boolean>> deleteProduct(@PathVariable Long Id) {

		Product pr = productRepo.findById(Id)
				.orElseThrow(() -> new ProductNotFoundException("Product isn't available or not exist with id: " + Id));

		productRepo.delete(pr);
		Map<String, Boolean> mp = new HashMap<>();
		mp.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(mp);
	}

	//SEARCH BY NAME
//	@GetMapping("/products/{prodname}")
//	public ResponseEntity<Product> getByProductName(@PathVariable String prodname) {
//		
//		Product pr = productRepo.findByProductName(prodname)
//				.orElseThrow(() -> new ProductNotFoundException("Product doesn't exists with this name: " + prodname));
//		
//		return ResponseEntity.ok(pr);
//	}

}
