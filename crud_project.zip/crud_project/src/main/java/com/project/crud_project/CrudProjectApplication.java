package com.project.crud_project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.project.crud_project.model.Product;
import com.project.crud_project.repository.ProductRepository;

@SpringBootApplication
public class CrudProjectApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(CrudProjectApplication.class, args);
	}
		
		@Autowired
		private ProductRepository prodRepo;
		
		@Override
		public void run(String...args0) throws Exception {
			prodRepo.save(new Product("Milk", 30, "Toned"));
			prodRepo.save(new Product("Laptop", 30000, "Gaming"));
			prodRepo.save(new Product("Chair", 2000, "Furniture"));
		}


}
