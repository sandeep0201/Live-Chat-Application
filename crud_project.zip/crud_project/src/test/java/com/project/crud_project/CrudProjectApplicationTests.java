package com.project.crud_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
