export class Product {
  productId: number;
  productName: string;
  productPrice: number;
  productDesc: string;

  constructor(prodId: number, prodName: string, prodPrice: number, prodDesc: string) {
    this.productId = prodId;
    this.productName = prodName;
    this.productPrice = prodPrice;
    this.productDesc = prodDesc;
  }
}
