import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../product';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css'],
})
export class ProductDetailsComponent implements OnInit {
  Id!: number;
  product: Product;
  result: String;

  constructor(
    private route: ActivatedRoute,
    private productservice: ProductserviceService
  ) {
    this.product = new Product(+'', '', +'', '');
    this.result = '';
  }

  ngOnInit(): void {
    this.Id = this.route.snapshot.params['Id'];
    this.product = new Product(+'', '', +'', '');
    if (this.Id){
      this.productservice.getProductById(this.Id).subscribe((data) => {
        this.product = data;
      },
      error => {
        console.log("Product Not Found!")
        this.result = "Product Not Found";
      });
    }
  }
}
