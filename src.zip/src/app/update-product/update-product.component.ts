import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { Product } from '../product';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css'],
})
export class UpdateProductComponent implements OnInit {
  Id!: number;
  product: Product;
  constructor(
    private productservice: ProductserviceService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.product = new Product(+'', '', +'', '');
  }

  ngOnInit(): void {
    this.Id = this.route.snapshot.params['Id'];
    this.productservice.getProductById(this.Id).subscribe(
      (data) => {
        this.product = data;
      },
      (error) => console.log(error)
    );
  }

  onSubmitform1(form: any) {
    this.productservice.updateProduct(this.Id, this.product).subscribe(
      (data) => {
        this.goToProductList();
      },
      (error) => console.log(error)
    );
  }

  goToProductList() {
    this.router.navigate(['/products']);
  }
}
