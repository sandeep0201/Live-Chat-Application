import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

  private baseURL = "http://localhost:8080/restful/products";

  constructor(private httpClient: HttpClient) { }

  getProductList(): Observable<Product[]> {
    return this.httpClient.get<Product[]>(`${this.baseURL}`)
  }

  createProduct(product: Product): Observable<Object> {
    return this.httpClient.post(`${this.baseURL}`, product);
  }

  getProductById(Id: number): Observable<Product> {
    return this.httpClient.get<Product>(`${this.baseURL}/${Id}`);
  }

  updateProduct(Id: number, product: Product): Observable<Object> {
    return this.httpClient.put(`${this.baseURL}/${Id}`, product);
  }

  deleteProduct(Id: number): Observable<Object> {
    return this.httpClient.delete(`${this.baseURL}/${Id}`);
  }

  getProductByName(Name: String): Observable<Product> {
    return this.httpClient.get<Product>(`${this.baseURL}/${Name}`);
  }
}
