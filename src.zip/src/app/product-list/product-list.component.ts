import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../product';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit{

  products: Product[]=[];

  constructor(private productservice: ProductserviceService,
    private router: Router){
    // this.products = [];
  }

  ngOnInit(): void {
    this.getProducts();
  }

  private getProducts() {
    this.productservice.getProductList().subscribe((data: Product[]) => {         //we didn't opened the obj here instead we used callback function
      this.products = data.slice();                                               //array ki copy if kch pass nhi kia inside bracket
    })

  }

  updateProduct(Id: number) {
    this.router.navigate(['update-product', Id]);
  }

  deleteProduct(Id: number) {
    this.productservice.deleteProduct(Id).subscribe(data => {
      console.log(data);
      this.getProducts();
    })
  }

  viewProduct(Id:number) {
    this.router.navigate(['prod-detail', Id]);
  }
}
