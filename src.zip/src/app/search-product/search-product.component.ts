import { PropertyRead } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { Product } from '../product';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-search-product',
  templateUrl: './search-product.component.html',
  styleUrls: ['./search-product.component.css']
})
export class SearchProductComponent implements OnInit{

  Id!: number;
  Name!: String;
  product: Product = new Product(+'', '', +'', '');

  constructor(private productservice: ProductserviceService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {

  }

  onSubmitform2(form: any) {
    console.log(this.product);
  }

  goToProductList() {
    this.router.navigate(['/products']);
  }

  searchdetail() {
    this.router.navigate([`/prod-detail/${this.product.productId}`])
  }
}
